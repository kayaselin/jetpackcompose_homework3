package com.example.deneme1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.deneme1.ui.theme.NotificationItem
import com.example.deneme1.ui.theme.MyTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var isDarkMode by remember { mutableStateOf(false) }
            MyTheme(darkTheme = isDarkMode) {
                NotificationScreen(isDarkMode = isDarkMode, onToggleTheme = {
                    isDarkMode = !isDarkMode
                })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationScreen(isDarkMode: Boolean, onToggleTheme: () -> Unit) {
    var isRefreshing by remember { mutableStateOf(false) }

    LaunchedEffect(isRefreshing) {
        if (isRefreshing) {
            delay(2000) // Simulate network request
            isRefreshing = false
        }
    }

    val backgroundColor = if (isDarkMode) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.background

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor) // Arka plan rengini tema ile eşleştir
            .padding(16.dp)
    ) {
        Text(
            text = stringResource(id = R.string.notification_title),
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Example items
        NotificationItem(
            name = stringResource(id = R.string.person_name_1),
            id = stringResource(id = R.string.person_id_1),
            status = stringResource(id = R.string.person_status_1),
            time = stringResource(id = R.string.notification_time_1),
            location = stringResource(id = R.string.notification_location_1),
            imageResource = R.drawable.pp1,
            onCallClick = { /* Handle call click */ }
        )

        NotificationItem(
            name = stringResource(id = R.string.person_name_2),
            id = stringResource(id = R.string.person_id_2),
            status = stringResource(id = R.string.person_status_2),
            time = stringResource(id = R.string.notification_time_2),
            location = stringResource(id = R.string.notification_location_2),
            imageResource = R.drawable.pp1,
            onCallClick = { /* Handle call click */ }
        )

        NotificationItem(
            name = stringResource(id = R.string.person_name_3),
            id = stringResource(id = R.string.person_id_3),
            status = stringResource(id = R.string.person_status_3),
            time = stringResource(id = R.string.notification_time_3),
            location = stringResource(id = R.string.notification_location_3),
            imageResource = R.drawable.pp1,
            onCallClick = { /* Handle call click */ }
        )

        NotificationItem(
            name = stringResource(id = R.string.person_name_4),
            id = stringResource(id = R.string.person_id_4),
            status = stringResource(id = R.string.person_status_4),
            time = stringResource(id = R.string.notification_time_4),
            location = stringResource(id = R.string.notification_location_4),
            imageResource = R.drawable.pp1,
            onCallClick = { /* Handle call click */ }
        )

        NotificationItem(
            name = stringResource(id = R.string.person_name_5),
            id = stringResource(id = R.string.person_id_5),
            status = stringResource(id = R.string.person_status_5),
            time = stringResource(id = R.string.notification_time_5),
            location = stringResource(id = R.string.notification_location_5),
            imageResource = R.drawable.pp1,
            onCallClick = { /* Handle call click */ }
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Theme Toggle Button
        Button(
            onClick = onToggleTheme,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
            Text(text = if (isDarkMode) "Switch to Light Mode" else "Switch to Dark Mode")
        }
    }
}
